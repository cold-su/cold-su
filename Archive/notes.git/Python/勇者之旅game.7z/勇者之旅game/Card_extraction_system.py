import time
import random
import sys
from tool import xiex1,xiex3
import tkinter.messagebox
from random import choices,randint
from sys import exit
import tkinter as tk
from tkinter import Place, font
from tkinter.constants import COMMAND, W, X, Y
tips = ['tip:履刑者抽卡全保底(','tip:tips','tip:这是很冷的冷知识','tip:这是很烫的热知识','tip:在？植个发？','tip:原来你也玩原神?','tip:我们联合!','tip:为斯卡蒂献上心脏!','tip:来跟我读p-r-o','tip:有BUG咩?','tip:这里是船馨版本','tip:告诉你tip有12条!']
upkac = ['可莉(火)五星','诺艾尔(岩)四星','班尼特(火)四星','以理服人(二星)','砂糖(风)四星','训练大刀(一星)']
wpkac = ['四风原典(五星)','试作斩岩(四星)','以理服人(二星)','咸鱼大剑(四星)','训练大刀(一星)']
def ckjm():
    window=tk.Tk()
    window.title('原神UP')
    window.geometry('700x500')#窗口
    tip=random.choice(tips)
    tk.Label(window,text=tip,font=('wtf',15)).place(x=0, y=470)
    tk.Label(window,text=xiex1,font=('wtf',15)).place(x=60, y=40)
    tk.Label(window,text=xiex1,font=('wtf',15)).place(x=60, y=315)
    tk.Label(window,text=xiex3,font=('wtf',15)).place(x=60,y=47)
    tk.Label(window,text=xiex3,font=('wtf',15)).place(x=610,y=47)
    tk.Label(window,text='人',font=('wtf',100)).place(x=410,y=150)
    tk.Label(window,text='概率UP',font=('wtf',20)).place(x=70,y=100)
    tk.Button(window, text='☆:',font=('wtf',12),width=6,height=1).place(x=640, y=0)
    def cz():
        tkinter.messagebox.showinfo(title='池子', message='')
    tk.Button(window, text='池子',font=('wtf',12),width=6,height=1,command=cz).place(x=640, y=30)
    tk.Button(window, text='一发 160',font=('wtf',15),width=9,height=1,).place(x=360, y=315)
    tk.Button(window, text='十发 1600',font=('wtf',15),width=9,height=1,).place(x=490, y=315)
    window.mainloop()
ckjm()
    
