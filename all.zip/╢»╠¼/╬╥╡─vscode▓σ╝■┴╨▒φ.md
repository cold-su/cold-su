# 我的vscode插件列表

- Project Manager

    用 Shift+Alt+P 可以在各个项目之间跳转，去设置里面配置“Git基本目录”（就是集中存放repo的那个目录，我的主要是 Document/GitHub）即可。当然也可以自己配置本地的项目，我主要还是用git多。强烈推荐此插件。

- Material Icon Theme
- GitHub Theme
- Chinese (Simplified) (简体中文) Language Pack for Visual Studio
- VSCode Neovim

    [我的Neovim配置](https://github.com/cold-su/nvim)

- Live Share

    多人协同写代码。

- Blur Menu

    这个插件可以开启动画效果，模糊效果可有可无。我主要是用它的动画效果。

- 各类语言拓展包
