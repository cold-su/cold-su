# 如何解决“PowerShell：……因为在此系统上禁止运行脚本”？

以管理员身份打开 PowerShell

```sh
set-executionpolicy remotesigned
```
