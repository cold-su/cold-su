# 分享B站视频链接会暴露身份

我有注意到B站网页端的链接末尾总会自动加上一串vd_source，我一看便知此为恶心的追踪参数。

网上也有[讨论](https://github.com/the1812/Bilibili-Evolved/discussions/3424)，我读完这个帖子之后得知了解决方法。

往Edge上装ClearURLs插件就好了。
