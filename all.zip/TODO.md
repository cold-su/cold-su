  #TODO 
## LeetCode

- [ ] [1395. Count Number of Teams](https://leetcode.com/problems/count-number-of-teams/description/?envType=daily-question&envId=2024-07-29)

## 专有名词

- [ ] 堆排序
  - [x] [排序算法：堆排序【图解+代码】](https://www.bilibili.com/video/BV1fp4y1D7cj/)
- [ ] 杜教筛
- [ ] 完全背包
- [ ] 基数排序
- [ ] BFS
- [ ] 杨表
- [ ] 二项式定理
- [ ] 拓扑排序
- [ ] 猫树
- [ ] 后缀自动机
- [ ] 桶排序
- [ ] 圆排列
- [ ] 单调栈
- [ ] 置换
- [ ] 平面最近点对
- [ ] 动态点分治
- [ ] 模拟费用流
- [ ] Lyndon分解
- [ ] K进制FWT
- [ ] Stern-Brocot树
- [ ] KMP算法
- [ ] 回滚莫队
